"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import type { LucideIcon } from "lucide-react";
import {
  Building2, Globe, Users, Briefcase, Star,
  ChevronLeft, ChevronRight, X, Check,
  Sparkles, Shield, Coffee, Laptop, BookOpen,
  TrendingUp, Zap, Heart, Award, AlertCircle,
  Plus, Info, CheckCircle2, ArrowLeft, Eye,
} from "lucide-react";

// ─── Types ───────────────────────────────────────────────────────────────────

interface CompanyData {
  name: string;
  tagline: string;
  website: string;
  industry: string;
  founded: string;
  logoText: string;
  logoColor: string;
  coverGradient: string;
  desc: string;
  size: string;
  workType: string;
  location: string;
  openJobs: string;
  twitter: string;
  linkedin: string;
  github: string;
  perks: string[];
  culture: string;
  techStack: string;
  featured: boolean;
  hiring: boolean;
}

interface FormErrors {
  name?: string;
  tagline?: string;
  website?: string;
  industry?: string;
  founded?: string;
  logoText?: string;
  desc?: string;
  size?: string;
  workType?: string;
  location?: string;
}

interface StepItem {
  id: number;
  label: string;
  icon: LucideIcon;
}

interface PerkItem {
  id: string;
  label: string;
  icon: LucideIcon;
}

interface LogoColorItem {
  id: string;
  label: string;
  cls: string;
}

interface GradientItem {
  id: string;
  label: string;
  cls: string;
}

// ─── Constants ───────────────────────────────────────────────────────────────
const INDUSTRIES: string[] = [
  "SaaS / Productivity","Fintech","AI & Machine Learning","Design Tools",
  "Developer Tools","E-commerce","Health & Wellness","HR Tech",
  "Infrastructure","Community & Media","Other",
];
const SIZES: string[]       = ["1 – 50","51 – 200","201 – 500","501 – 1,000","1,000+"];
const WORK_TYPES: string[]  = ["Fully Remote","Remote-first","Hybrid","On-site"];
const FOUNDED_YRS: number[] = Array.from({ length: 75 }, (_, i) => 2024 - i);

const PERKS: PerkItem[] = [
  { id:"health",     label:"Health Insurance",   icon:Shield     },
  { id:"flexible",   label:"Flexible Hours",      icon:Coffee     },
  { id:"homeoffice", label:"Home Office Budget",  icon:Laptop     },
  { id:"learning",   label:"Learning Budget",     icon:BookOpen   },
  { id:"equity",     label:"Equity / Stock",      icon:TrendingUp },
  { id:"pto",        label:"Unlimited PTO",       icon:Star       },
  { id:"async",      label:"Async-first",         icon:Zap        },
  { id:"retreats",   label:"Team Retreats",       icon:Globe      },
  { id:"wellness",   label:"Mental Wellness",     icon:Heart      },
  { id:"pension",    label:"401k / Pension",      icon:Award      },
];

const LOGO_COLORS: LogoColorItem[] = [
  { id:"indigo",  label:"Indigo",  cls:"bg-indigo-600"  },
  { id:"violet",  label:"Violet",  cls:"bg-violet-700"  },
  { id:"blue",    label:"Blue",    cls:"bg-blue-700"    },
  { id:"cyan",    label:"Cyan",    cls:"bg-cyan-600"    },
  { id:"emerald", label:"Emerald", cls:"bg-emerald-600" },
  { id:"teal",    label:"Teal",    cls:"bg-teal-600"    },
  { id:"orange",  label:"Orange",  cls:"bg-orange-500"  },
  { id:"pink",    label:"Pink",    cls:"bg-pink-600"    },
  { id:"red",     label:"Red",     cls:"bg-red-500"     },
  { id:"amber",   label:"Amber",   cls:"bg-amber-500"   },
  { id:"gray",    label:"Gray",    cls:"bg-gray-900"    },
  { id:"purple",  label:"Purple",  cls:"bg-purple-600"  },
];

const GRADIENTS: GradientItem[] = [
  { id:"ig",  label:"Indigo Violet", cls:"from-indigo-600 to-violet-700"  },
  { id:"gd",  label:"Graphite",      cls:"from-gray-700 to-gray-950"      },
  { id:"yo",  label:"Sunrise",       cls:"from-yellow-400 to-orange-500"  },
  { id:"vi",  label:"Aurora",        cls:"from-violet-600 to-indigo-800"  },
  { id:"et",  label:"Forest",        cls:"from-emerald-500 to-teal-700"   },
  { id:"pr",  label:"Blush",         cls:"from-pink-500 to-rose-700"      },
  { id:"oa",  label:"Ember",         cls:"from-orange-500 to-amber-600"   },
  { id:"bp",  label:"Ocean",         cls:"from-blue-500 to-indigo-700"    },
  { id:"cb",  label:"Sky",           cls:"from-cyan-500 to-blue-700"      },
  { id:"rr",  label:"Crimson",       cls:"from-red-500 to-rose-700"       },
  { id:"te",  label:"Jade",          cls:"from-teal-500 to-emerald-700"   },
  { id:"pv",  label:"Twilight",      cls:"from-purple-600 to-violet-800"  },
];

const STEPS: StepItem[] = [
  { id:1, label:"Basic Info",      icon:Building2 },
  { id:2, label:"Details",         icon:Briefcase },
  { id:3, label:"Culture & Perks", icon:Heart     },
  { id:4, label:"Preview",         icon:Eye       },
];

// ─── Design-token helpers ─────────────────────────────────────────────────────
const fieldBase =
  "w-full px-4 py-3 rounded-xl border text-sm font-medium outline-none transition-all";
const fieldNormal =
  "border-[var(--color-border-light)] bg-[var(--color-slate-50)] " +
  "text-[var(--color-text-primary)] placeholder-[var(--color-text-muted)] " +
  "focus:border-[var(--color-accent-primary)] focus:bg-[var(--color-background-alt)] " +
  "focus:ring-2 focus:ring-[var(--color-primary-100)]";
const fieldErr =
  "border-[var(--color-error)] bg-[var(--color-error-light)] " +
  "text-[var(--color-text-primary)] placeholder-[var(--color-text-muted)] " +
  "focus:border-[var(--color-error)] focus:ring-2 focus:ring-[var(--color-red-100)]";

const chevron = encodeURIComponent(
  `<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="%239ca3af" stroke-width="2.5"><path d="M6 9l6 6 6-6"/></svg>`
);

// ─── Primitives ───────────────────────────────────────────────────────────────
interface FieldLabelProps {
  children: React.ReactNode;
  required?: boolean;
}

function FieldLabel({ children, required }: FieldLabelProps) {
  return (
    <label className="block mb-2 uppercase tracking-widest font-black"
      style={{ fontSize:"11px", color:"var(--color-text-secondary)" }}>
      {children}
      {required && <span style={{ color:"var(--color-error)" }} className="ml-1">*</span>}
    </label>
  );
}

interface FieldErrorProps {
  msg?: string;
}

function FieldError({ msg }: FieldErrorProps) {
  if (!msg) return null;
  return (
    <p className="flex items-center gap-1 mt-1.5 font-medium"
      style={{ fontSize:"11.5px", color:"var(--color-error)" }}>
      <AlertCircle className="w-3 h-3 flex-shrink-0" /> {msg}
    </p>
  );
}

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  error?: string;
}

function Input({ error, ...props }: InputProps) {
  return (
    <div>
      <input {...props} className={`${fieldBase} ${error ? fieldErr : fieldNormal}`} />
      <FieldError msg={error} />
    </div>
  );
}

interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  error?: string;
}

function Textarea({ error, ...props }: TextareaProps) {
  return (
    <div>
      <textarea {...props} className={`${fieldBase} ${error ? fieldErr : fieldNormal} resize-none`} />
      <FieldError msg={error} />
    </div>
  );
}

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  error?: string;
  children: React.ReactNode;
}

function Select({ error, children, ...props }: SelectProps) {
  return (
    <div>
      <select
        {...props}
        className={`${fieldBase} ${error ? fieldErr : fieldNormal} appearance-none cursor-pointer bg-no-repeat`}
        style={{ backgroundImage:`url("data:image/svg+xml,${chevron}")`, backgroundPosition:"right 14px center" }}
      >
        {children}
      </select>
      <FieldError msg={error} />
    </div>
  );
}

interface CardProps {
  className?: string;
  style?: React.CSSProperties;
  children: React.ReactNode;
}

function Card({ className = "", style = {}, children }: CardProps) {
  return (
    <div
      className={`rounded-2xl p-5 sm:p-6 mb-5 ${className}`}
      style={{
        background:"var(--color-background-card)",
        border:"1px solid var(--color-border-subtle)",
        boxShadow:"var(--shadow-card)",
        ...style,
      }}
    >
      {children}
    </div>
  );
}

interface SectionCardProps {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}

function SectionCard({ title, subtitle, children }: SectionCardProps) {
  return (
    <Card>
      <div className="mb-5">
        <h3 className="font-black" style={{ fontSize:"15px", color:"var(--color-text-primary)" }}>{title}</h3>
        {subtitle && <p className="mt-0.5" style={{ fontSize:"12.5px", color:"var(--color-text-muted)" }}>{subtitle}</p>}
      </div>
      {children}
    </Card>
  );
}

// ─── Step Indicator ───────────────────────────────────────────────────────────
interface StepIndicatorProps {
  current: number;
}

function StepIndicator({ current }: StepIndicatorProps) {
  return (
    <div className="flex items-center flex-wrap gap-y-2">
      {STEPS.map((s, i) => {
        const done   = current > s.id;
        const active = current === s.id;
        const Icon   = s.icon;
        return (
          <div key={s.id} className="flex items-center">
            <div
              className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl transition-all font-bold whitespace-nowrap"
              style={{
                fontSize:"12px",
                background: active ? "var(--color-accent-primary)"
                          : done   ? "var(--color-emerald-50)" : "transparent",
                color:      active ? "var(--color-white)"
                          : done   ? "var(--color-emerald-700)" : "var(--color-text-muted)",
                border:     done   ? "1px solid var(--color-emerald-200)" : "1px solid transparent",
              }}
            >
              {done
                ? <CheckCircle2 className="w-3.5 h-3.5 flex-shrink-0" />
                : <Icon className="w-3.5 h-3.5 flex-shrink-0" />}
              <span className="hidden xs:hidden sm:inline">{s.label}</span>
            </div>
            {i < STEPS.length - 1 && (
              <div
                className="w-4 sm:w-6 h-0.5 mx-0.5 sm:mx-1 rounded flex-shrink-0"
                style={{ background: done ? "var(--color-emerald-200)" : "var(--color-border-subtle)" }}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}

// ─── Preview Card ─────────────────────────────────────────────────────────────
interface PreviewCardProps {
  data: CompanyData;
}

function PreviewCard({ data }: PreviewCardProps) {
  const logoCls    = LOGO_COLORS.find(c => c.id === data.logoColor)?.cls     || "bg-indigo-600";
  const gradCls    = GRADIENTS.find(g => g.id === data.coverGradient)?.cls   || "from-indigo-600 to-violet-700";
  const shownPerks = PERKS.filter(p => data.perks.includes(p.id)).slice(0, 3);

  return (
    <div className="rounded-2xl overflow-hidden"
      style={{ background:"var(--color-background-card)", border:"1px solid var(--color-border-subtle)", boxShadow:"var(--shadow-card)" }}>
      {/* Cover */}
      <div className={`h-20 bg-gradient-to-r ${gradCls} relative`}>
        {data.hiring && (
          <span className="absolute top-2.5 right-2.5 flex items-center gap-1 font-bold px-2.5 py-1 rounded-full"
            style={{ fontSize:"10px", background:"var(--color-emerald-500)", color:"var(--color-white)" }}>
            <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background:"var(--color-white)" }} />
            Hiring
          </span>
        )}
      </div>
      {/* Body */}
      <div className="px-4 pb-4">
        <div className="relative -mt-5 mb-2.5">
          <div
            className={`${logoCls} w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm border-2`}
            style={{ borderColor:"var(--color-background-alt)", boxShadow:"var(--shadow-md)", color:"var(--color-white)" }}>
            {data.logoText || "?"}
          </div>
        </div>
        <p className="font-black" style={{ fontSize:"14px", color:"var(--color-text-primary)" }}>
          {data.name || "Company Name"}
        </p>
        <p className="mt-0.5" style={{ fontSize:"11.5px", color:"var(--color-text-muted)" }}>
          {data.tagline || "Your tagline appears here"}
        </p>
        <div className="flex flex-wrap gap-x-2.5 gap-y-1 mt-2.5">
          {data.location && (
            <span className="flex items-center gap-1" style={{ fontSize:"11px", color:"var(--color-text-muted)" }}>
              <Globe className="w-3 h-3" /> {data.location}
            </span>
          )}
          {data.size && (
            <span className="flex items-center gap-1" style={{ fontSize:"11px", color:"var(--color-text-muted)" }}>
              <Users className="w-3 h-3" /> {data.size}
            </span>
          )}
        </div>
        {shownPerks.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mt-2.5">
            {shownPerks.map(p => {
              const Icon = p.icon;
              return (
                <span key={p.id} className="flex items-center gap-1 font-semibold px-2 py-1 rounded-lg"
                  style={{ fontSize:"10.5px", background:"var(--color-slate-50)", color:"var(--color-text-secondary)", border:"1px solid var(--color-border-subtle)" }}>
                  <Icon className="w-2.5 h-2.5" /> {p.label}
                </span>
              );
            })}
          </div>
        )}
        <div className="flex items-center justify-between mt-3 pt-3"
          style={{ borderTop:"1px solid var(--color-border-subtle)" }}>
          <div className="flex items-center gap-1.5 flex-wrap">
            {data.workType && (
              <span className="font-bold px-2 py-0.5 rounded-lg" style={{
                fontSize:"10.5px",
                background: data.workType === "Fully Remote"  ? "var(--color-emerald-50)"
                          : data.workType === "Remote-first"  ? "var(--color-primary-50)"
                          : "var(--color-amber-50)",
                color:      data.workType === "Fully Remote"  ? "var(--color-emerald-700)"
                          : data.workType === "Remote-first"  ? "var(--color-primary-700)"
                          : "var(--color-amber-600)",
              }}>
                {data.workType}
              </span>
            )}
          </div>
          <span className="flex items-center gap-1 font-bold"
            style={{ fontSize:"11px", color:"var(--color-accent-primary)" }}>
            <Briefcase className="w-2.5 h-2.5" /> {data.openJobs || 0} jobs
          </span>
        </div>
      </div>
    </div>
  );
}

// ─── Step 1 ───────────────────────────────────────────────────────────────────
interface StepProps {
  data: CompanyData;
  onChange: (key: keyof CompanyData, val: string | string[] | boolean) => void;
  errors: FormErrors;
}

function Step1({ data, onChange, errors }: StepProps) {
  return (
    <motion.div initial={{ opacity:0, x:20 }} animate={{ opacity:1, x:0 }} exit={{ opacity:0, x:-20 }} transition={{ duration:0.28 }}>
      <SectionCard title="Company Identity" subtitle="The basics — what your company is called and how it appears in search.">
        <div className="space-y-5">
          <div>
            <FieldLabel required>Company Name</FieldLabel>
            <Input type="text" placeholder="e.g. Acme Inc."
              value={data.name} onChange={e => onChange("name", e.target.value)} error={errors.name} />
          </div>
          <div>
            <FieldLabel required>Tagline</FieldLabel>
            <Input type="text" placeholder="e.g. The all-in-one platform for teams"
              value={data.tagline} onChange={e => onChange("tagline", e.target.value)} maxLength={80} error={errors.tagline} />
            <p className="mt-1" style={{ fontSize:"11px", color:"var(--color-text-muted)" }}>{data.tagline.length}/80 characters</p>
          </div>
          <div>
            <FieldLabel required>Website</FieldLabel>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-sm font-medium pointer-events-none select-none"
                style={{ color:"var(--color-text-muted)" }}>https://</span>
              <input type="text" placeholder="yourcompany.com"
                value={data.website} onChange={e => onChange("website", e.target.value)}
                className={`${fieldBase} ${errors.website ? fieldErr : fieldNormal}`}
                style={{ paddingLeft:"4rem" }} />
            </div>
            <FieldError msg={errors.website} />
          </div>
          {/* Stack on mobile, side-by-side on sm+ */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <FieldLabel required>Industry</FieldLabel>
              <Select value={data.industry} onChange={e => onChange("industry", e.target.value)} error={errors.industry}>
                <option value="">Select industry…</option>
                {INDUSTRIES.map(i => <option key={i} value={i}>{i}</option>)}
              </Select>
            </div>
            <div>
              <FieldLabel required>Year Founded</FieldLabel>
              <Select value={data.founded} onChange={e => onChange("founded", e.target.value)} error={errors.founded}>
                <option value="">Select year…</option>
                {FOUNDED_YRS.map(y => <option key={y} value={y}>{y}</option>)}
              </Select>
            </div>
          </div>
        </div>
      </SectionCard>

      <SectionCard title="Logo & Branding" subtitle="Customize how your company looks in the directory.">
        <div className="space-y-5">
          <div>
            <FieldLabel required>Logo Text / Initials</FieldLabel>
            <Input type="text" placeholder="e.g. AC or 🚀"
              value={data.logoText} onChange={e => onChange("logoText", e.target.value.slice(0, 3))} maxLength={3} error={errors.logoText} />
            <p className="mt-1" style={{ fontSize:"11px", color:"var(--color-text-muted)" }}>Up to 3 characters or an emoji</p>
          </div>
          <div>
            <FieldLabel>Logo Background Color</FieldLabel>
            <div className="flex flex-wrap gap-2 mt-1">
              {LOGO_COLORS.map(c => (
                <button key={c.id} type="button" onClick={() => onChange("logoColor", c.id)} title={c.label}
                  className={`w-8 h-8 rounded-lg ${c.cls} flex items-center justify-center flex-shrink-0 transition-transform hover:scale-105 ${
                    data.logoColor === c.id ? "ring-2 ring-offset-2 ring-[var(--color-accent-primary)] scale-110" : ""}`}>
                  {data.logoColor === c.id && <Check className="w-3.5 h-3.5" style={{ color:"var(--color-white)" }} />}
                </button>
              ))}
            </div>
          </div>
          <div>
            <FieldLabel>Cover Gradient</FieldLabel>
            {/* 6 cols on sm+, 4 cols on mobile */}
            <div className="grid grid-cols-4 sm:grid-cols-6 gap-2 mt-1">
              {GRADIENTS.map(g => (
                <button key={g.id} type="button" onClick={() => onChange("coverGradient", g.id)} title={g.label}
                  className={`h-9 rounded-lg bg-gradient-to-r ${g.cls} transition-transform hover:scale-105 ${
                    data.coverGradient === g.id ? "ring-2 ring-offset-2 ring-[var(--color-accent-primary)] scale-105" : ""}`} />
              ))}
            </div>
          </div>
        </div>
      </SectionCard>
    </motion.div>
  );
}

// ─── Step 2 ───────────────────────────────────────────────────────────────────
function Step2({ data, onChange, errors }: StepProps) {
  return (
    <motion.div initial={{ opacity:0, x:20 }} animate={{ opacity:1, x:0 }} exit={{ opacity:0, x:-20 }} transition={{ duration:0.28 }}>
      <SectionCard title="Company Overview" subtitle="Help candidates understand what your company does.">
        <FieldLabel required>Description</FieldLabel>
        <Textarea placeholder="Describe your company — what you build, who you serve, and what makes you unique…"
          value={data.desc} onChange={e => onChange("desc", e.target.value)} rows={5} maxLength={500} error={errors.desc} />
        <p className="mt-1" style={{ fontSize:"11px", color:"var(--color-text-muted)" }}>{data.desc.length}/500 characters</p>
      </SectionCard>

      <SectionCard title="Team & Structure" subtitle="Tell us about your team size, location, and how you work.">
        <div className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <FieldLabel required>Company Size</FieldLabel>
              <Select value={data.size} onChange={e => onChange("size", e.target.value)} error={errors.size}>
                <option value="">Select size…</option>
                {SIZES.map(s => <option key={s} value={s}>{s} employees</option>)}
              </Select>
            </div>
            <div>
              <FieldLabel required>Work Model</FieldLabel>
              <Select value={data.workType} onChange={e => onChange("workType", e.target.value)} error={errors.workType}>
                <option value="">Select model…</option>
                {WORK_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
              </Select>
            </div>
          </div>
          <div>
            <FieldLabel required>Location(s)</FieldLabel>
            <Input type="text" placeholder="e.g. USA · Global  or  Europe  or  Remote"
              value={data.location} onChange={e => onChange("location", e.target.value)} error={errors.location} />
            <p className="mt-1" style={{ fontSize:"11px", color:"var(--color-text-muted)" }}>
              List main regions, separated by · (middle dot)
            </p>
          </div>
          <div>
            <FieldLabel>Open Job Positions</FieldLabel>
            <div className="relative">
              <Briefcase className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 pointer-events-none"
                style={{ color:"var(--color-text-muted)" }} />
              <input type="number" min="0" placeholder="0"
                value={data.openJobs} onChange={e => onChange("openJobs", e.target.value)}
                className={`${fieldBase} ${fieldNormal}`} style={{ paddingLeft:"2.75rem" }} />
            </div>
          </div>
        </div>
      </SectionCard>

      <SectionCard title="Social & Links" subtitle="Optional but recommended for more profile visibility.">
        <div className="space-y-4">
          {[
            { key:"twitter" as const,  label:"Twitter / X", ph:"@yourcompany"                       },
            { key:"linkedin" as const, label:"LinkedIn",     ph:"linkedin.com/company/yourcompany"   },
            { key:"github" as const,   label:"GitHub",       ph:"github.com/yourcompany"             },
          ].map(f => (
            <div key={f.key}>
              <FieldLabel>{f.label}</FieldLabel>
              <Input type="text" placeholder={f.ph} value={data[f.key] || ""} onChange={e => onChange(f.key, e.target.value)} />
            </div>
          ))}
        </div>
      </SectionCard>
    </motion.div>
  );
}

// ─── Step 3 ───────────────────────────────────────────────────────────────────
interface Step3Props {
  data: CompanyData;
  onChange: (key: keyof CompanyData, val: string | string[] | boolean) => void;
}

function Step3({ data, onChange }: Step3Props) {
  const toggle = (id: string) => onChange("perks",
    data.perks.includes(id) ? data.perks.filter(p => p !== id) : [...data.perks, id]
  );

  return (
    <motion.div initial={{ opacity:0, x:20 }} animate={{ opacity:1, x:0 }} exit={{ opacity:0, x:-20 }} transition={{ duration:0.28 }}>
      <SectionCard title="Benefits & Perks" subtitle="Select all that apply — candidates filter by these.">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {PERKS.map(perk => {
            const Icon = perk.icon;
            const on   = data.perks.includes(perk.id);
            return (
              <button key={perk.id} type="button" onClick={() => toggle(perk.id)}
                className="flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all"
                style={{
                  border:     on ? "2px solid var(--color-accent-primary)" : "2px solid var(--color-border-subtle)",
                  background: on ? "var(--color-primary-50)" : "var(--color-slate-50)",
                  color:      on ? "var(--color-primary-700)" : "var(--color-text-secondary)",
                }}>
                <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                  style={{
                    background: on ? "var(--color-primary-100)" : "var(--color-background-alt)",
                    border:     on ? "none" : "1px solid var(--color-border-light)",
                  }}>
                  <Icon className="w-4 h-4" style={{ color: on ? "var(--color-accent-primary)" : "var(--color-text-muted)" }} />
                </div>
                <span className="text-xs sm:text-[12.5px] font-bold leading-tight flex-1">{perk.label}</span>
                {on && <CheckCircle2 className="w-4 h-4 flex-shrink-0" style={{ color:"var(--color-accent-primary)" }} />}
              </button>
            );
          })}
        </div>
        <p className="mt-3" style={{ fontSize:"11.5px", color:"var(--color-text-muted)" }}>
          {data.perks.length} of {PERKS.length} perks selected
        </p>
      </SectionCard>

      <SectionCard title="Company Culture" subtitle="Optional: describe what it's like to work here.">
        <div className="space-y-5">
          <div>
            <FieldLabel>Culture Statement</FieldLabel>
            <Textarea placeholder="e.g. We believe in radical transparency, async-first communication, and shipping fast…"
              value={data.culture || ""} onChange={e => onChange("culture", e.target.value)} rows={4} maxLength={300} />
            <p className="mt-1" style={{ fontSize:"11px", color:"var(--color-text-muted)" }}>
              {(data.culture || "").length}/300 characters
            </p>
          </div>
          <div>
            <FieldLabel>
              Tech Stack{" "}
              <span className="font-normal normal-case tracking-normal"
                style={{ fontSize:"10.5px", color:"var(--color-text-muted)" }}>(optional)</span>
            </FieldLabel>
            <Input type="text" placeholder="e.g. React, TypeScript, Go, PostgreSQL, AWS…"
              value={data.techStack || ""} onChange={e => onChange("techStack", e.target.value)} />
          </div>
        </div>
      </SectionCard>

      <SectionCard title="Visibility Settings" subtitle="Control how your listing is presented.">
        <div className="space-y-3">
          {[
            { key:"featured" as const, label:"Mark as Featured", desc:"Highlighted in the Featured Companies banner" },
            { key:"hiring" as const,   label:"Currently Hiring", desc:"Shows a green 'Hiring' badge on your card"   },
          ].map(opt => (
            <div key={opt.key}
              className="flex items-start justify-between gap-4 p-4 rounded-xl cursor-pointer transition-colors"
              style={{ background:"var(--color-slate-50)", border:"1px solid var(--color-border-subtle)" }}
              onClick={() => onChange(opt.key, !data[opt.key])}>
              <div>
                <p className="text-sm font-bold" style={{ color:"var(--color-text-primary)" }}>{opt.label}</p>
                <p className="mt-0.5" style={{ fontSize:"11.5px", color:"var(--color-text-muted)" }}>{opt.desc}</p>
              </div>
              {/* Toggle */}
              <div className="relative flex-shrink-0 w-11 h-6 rounded-full transition-colors"
                style={{ background: data[opt.key] ? "var(--color-accent-primary)" : "var(--color-slate-300)" }}>
                <span className="absolute top-0.5 w-5 h-5 bg-white rounded-full transition-transform"
                  style={{ transform: data[opt.key] ? "translateX(1.25rem)" : "translateX(0.125rem)", boxShadow:"var(--shadow-sm)" }} />
              </div>
            </div>
          ))}
        </div>
      </SectionCard>
    </motion.div>
  );
}

// ─── Step 4 ───────────────────────────────────────────────────────────────────
interface Step4Props {
  data: CompanyData;
  onSubmit: () => void;
  submitted: boolean;
}

function Step4({ data, onSubmit, submitted }: Step4Props) {
  const logoCls = LOGO_COLORS.find(c => c.id === data.logoColor)?.cls   || "bg-indigo-600";
  const gradCls = GRADIENTS.find(g => g.id === data.coverGradient)?.cls || "from-indigo-600 to-violet-700";

  if (submitted) return (
    <motion.div initial={{ opacity:0, scale:0.96 }} animate={{ opacity:1, scale:1 }}
      className="rounded-2xl p-8 sm:p-12 text-center"
      style={{ background:"var(--color-background-card)", border:"1px solid var(--color-border-subtle)", boxShadow:"var(--shadow-card)" }}>
      <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-5"
        style={{ background:"var(--color-emerald-100)" }}>
        <CheckCircle2 className="w-8 h-8" style={{ color:"var(--color-emerald-600)" }} />
      </div>
      <h3 className="text-xl font-black mb-2" style={{ color:"var(--color-text-primary)" }}>Company Submitted!</h3>
      <p className="text-sm max-w-xs mx-auto mb-6" style={{ color:"var(--color-text-muted)" }}>
        Your listing is under review and will appear in the directory within 24 hours.
      </p>
      <div className={`bg-gradient-to-r ${gradCls} rounded-2xl p-1 max-w-xs mx-auto`}>
        <div className="rounded-xl p-4 text-left" style={{ background:"var(--color-background-alt)" }}>
          <div className={`${logoCls} w-10 h-10 rounded-lg flex items-center justify-center font-black text-sm mb-3`}
            style={{ color:"var(--color-white)" }}>{data.logoText || "?"}</div>
          <p className="font-black text-sm" style={{ color:"var(--color-text-primary)" }}>{data.name}</p>
          <p style={{ fontSize:"12px", color:"var(--color-text-muted)" }}>{data.tagline}</p>
        </div>
      </div>
    </motion.div>
  );

  return (
    <motion.div initial={{ opacity:0, x:20 }} animate={{ opacity:1, x:0 }} exit={{ opacity:0, x:-20 }} transition={{ duration:0.28 }}>
      {/* Warning banner */}
      <div className="flex items-start gap-3 p-4 rounded-xl mb-5"
        style={{ background:"var(--color-warning-light)", border:"1px solid var(--color-amber-200)" }}>
        <Info className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color:"var(--color-warning-dark)" }} />
        <div>
          <p className="text-sm font-bold" style={{ color:"var(--color-amber-700)" }}>Review your listing</p>
          <p style={{ fontSize:"12px", color:"var(--color-amber-600)", marginTop:"2px" }}>
            This is exactly how candidates will see your company. Make sure everything looks right before submitting.
          </p>
        </div>
      </div>

      <SectionCard title="Company Card Preview" subtitle="How your listing appears in the directory.">
        <PreviewCard data={data} />
      </SectionCard>

      <SectionCard title="Listing Summary">
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {[
            ["Company",    data.name      || "—"],
            ["Industry",   data.industry  || "—"],
            ["Size",       data.size ? `${data.size} employees` : "—"],
            ["Work Model", data.workType  || "—"],
            ["Location",   data.location  || "—"],
            ["Founded",    data.founded   || "—"],
            ["Website",    data.website   || "—"],
            ["Open Jobs",  data.openJobs  || "0"],
            ["Featured",   data.featured  ? "Yes" : "No"],
            ["Hiring",     data.hiring    ? "Yes" : "No"],
          ].map(([k, v]) => (
            <div key={k} className="flex flex-col gap-0.5 rounded-xl px-3 py-2.5"
              style={{ background:"var(--color-slate-50)" }}>
              <span className="uppercase tracking-widest font-black"
                style={{ fontSize:"10px", color:"var(--color-text-muted)" }}>{k}</span>
              <span className="font-bold truncate" style={{ fontSize:"12.5px", color:"var(--color-text-primary)" }}>{v}</span>
            </div>
          ))}
        </div>

        {data.perks.length > 0 && (
          <div className="mt-4">
            <p className="uppercase tracking-widest font-black mb-2"
              style={{ fontSize:"10px", color:"var(--color-text-muted)" }}>Perks & Benefits</p>
            <div className="flex flex-wrap gap-1.5">
              {PERKS.filter(p => data.perks.includes(p.id)).map(p => {
                const Icon = p.icon;
                return (
                  <span key={p.id} className="flex items-center gap-1 font-semibold px-2 py-1 rounded-lg"
                    style={{ fontSize:"11px", background:"var(--color-primary-50)", color:"var(--color-primary-700)", border:"1px solid var(--color-primary-100)" }}>
                    <Icon className="w-3 h-3" /> {p.label}
                  </span>
                );
              })}
            </div>
          </div>
        )}
      </SectionCard>

      <button onClick={onSubmit}
        className="btn btn-primary w-full flex items-center justify-center gap-2.5 py-4 rounded-2xl font-black text-sm"
        style={{ boxShadow:"var(--shadow-primary-md)" }}>
        <Sparkles className="w-4 h-4" /> Submit Company Listing
      </button>
      <p className="text-center mt-3" style={{ fontSize:"11.5px", color:"var(--color-text-muted)" }}>
        By submitting, you agree to our content guidelines. Listings are reviewed within 24 hours.
      </p>
    </motion.div>
  );
}

// ─── Mobile Preview Sheet ─────────────────────────────────────────────────────
interface MobileSheetProps {
  data: CompanyData;
  open: boolean;
  onClose: () => void;
}

function MobileSheet({ data, open, onClose }: MobileSheetProps) {
  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }} exit={{ opacity:0 }}
            className="fixed inset-0 z-40 lg:hidden"
            style={{ background:"rgba(0,0,0,0.45)" }}
            onClick={onClose} />
          <motion.div
            initial={{ y:"100%" }} animate={{ y:0 }} exit={{ y:"100%" }}
            transition={{ type:"spring", damping:26, stiffness:280 }}
            className="fixed bottom-0 left-0 right-0 z-50 rounded-t-3xl p-5 pb-10 lg:hidden overflow-y-auto"
            style={{ background:"var(--color-background-card)", boxShadow:"var(--shadow-2xl)", maxHeight:"85vh" }}>
            <div className="w-10 h-1 rounded-full mx-auto mb-4"
              style={{ background:"var(--color-border-medium)" }} />
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4" style={{ color:"var(--color-accent-primary)" }} />
                <span className="font-black uppercase tracking-widest"
                  style={{ fontSize:"11px", color:"var(--color-text-secondary)" }}>Live Preview</span>
              </div>
              <button onClick={onClose} className="p-1 rounded-lg transition-colors"
                style={{ color:"var(--color-text-muted)" }}>
                <X className="w-4 h-4" />
              </button>
            </div>
            <PreviewCard data={data} />
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function AddCompany() {
  const [step,        setStep]        = useState<number>(1);
  const [submitted,   setSubmitted]   = useState<boolean>(false);
  const [sheetOpen,   setSheetOpen]   = useState<boolean>(false);
  const [errors,      setErrors]      = useState<FormErrors>({});
  const [data,        setData]        = useState<CompanyData>({
    name:"", tagline:"", website:"", industry:"", founded:"",
    logoText:"", logoColor:"indigo", coverGradient:"ig",
    desc:"", size:"", workType:"", location:"", openJobs:"",
    twitter:"", linkedin:"", github:"",
    perks:[], culture:"", techStack:"",
    featured:false, hiring:true,
  });

  const onChange = (key: keyof CompanyData, val: string | string[] | boolean) => {
    setData(d => ({ ...d, [key]: val }));
    if (errors[key as keyof FormErrors]) setErrors(e => { const n={...e}; delete n[key as keyof FormErrors]; return n; });
  };

  const validate = (s: number): FormErrors => {
    const e: FormErrors = {};
    if (s===1) {
      if (!data.name.trim())     e.name     = "Company name is required";
      if (!data.tagline.trim())  e.tagline  = "Tagline is required";
      if (!data.website.trim())  e.website  = "Website is required";
      if (!data.industry)        e.industry = "Please select an industry";
      if (!data.founded)         e.founded  = "Please select a founding year";
      if (!data.logoText.trim()) e.logoText = "Logo text is required";
    }
    if (s===2) {
      if (!data.desc.trim())     e.desc     = "Description is required";
      if (!data.size)            e.size     = "Please select a company size";
      if (!data.workType)        e.workType = "Please select a work model";
      if (!data.location.trim()) e.location = "Location is required";
    }
    return e;
  };

  const next = () => {
    const e = validate(step);
    if (Object.keys(e).length) { setErrors(e); return; }
    setErrors({});
    setStep(s => Math.min(4, s+1));
    window.scrollTo({ top:0, behavior:"smooth" });
  };
  const prev = () => {
    setStep(s => Math.max(1, s-1));
    window.scrollTo({ top:0, behavior:"smooth" });
  };

  return (
    <div className="min-h-screen bg-page" style={{ fontFamily:"var(--font-sans)" }}>

      {/* ── Hero ── */}
      <div className="gradient-hero-dark pt-16 sm:pt-20 pb-8 sm:pb-10 px-4 relative overflow-hidden">
        {/* Decorative glows */}
        <div className="absolute top-0 left-1/4 w-64 sm:w-96 h-64 sm:h-96 rounded-full blur-3xl pointer-events-none"
          style={{ background:"rgba(37,99,235,0.10)" }} />
        <div className="absolute bottom-0 right-1/4 w-48 sm:w-72 h-48 sm:h-72 rounded-full blur-3xl pointer-events-none"
          style={{ background:"rgba(14,165,233,0.08)" }} />

        <div className="max-w-5xl mx-auto relative">
          <a href="#"
            className="inline-flex items-center gap-2 text-sm font-semibold mb-5 transition-colors hover:text-white"
            style={{ color:"var(--color-slate-400)" }}>
            <ArrowLeft className="w-4 h-4" /> Back to Browse Companies
          </a>

          {/* Hero body */}
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-5">
            <motion.div initial={{ opacity:0, y:16 }} animate={{ opacity:1, y:0 }} transition={{ duration:0.4 }}>
              {/* pill badge */}
              <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-widest uppercase px-4 py-1.5 rounded-full mb-3"
                style={{ background:"rgba(37,99,235,0.20)", border:"1px solid rgba(96,165,250,0.30)", color:"var(--color-primary-300)" }}>
                <Plus className="w-3 h-3" /> Add Your Company
              </div>
              <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black leading-tight tracking-tight"
                style={{ color:"var(--color-white)" }}>
                List Your Company
                <span className="block text-transparent bg-clip-text"
                  style={{ backgroundImage:"linear-gradient(to right, var(--color-primary-300), var(--color-sky-300))" }}>
                  in the Directory
                </span>
              </h1>
              <p className="mt-2 text-sm max-w-md" style={{ color:"var(--color-slate-400)" }}>
                Reach thousands of remote-first candidates actively looking for their next role.
              </p>
            </motion.div>

            {/* Stat pills */}
            <motion.div initial={{ opacity:0, y:10 }} animate={{ opacity:1, y:0 }} transition={{ delay:0.15 }}
              className="flex gap-3 sm:gap-4 flex-wrap">
              {[["Free","to list"],["24h","review time"],["10k+","monthly views"]].map(([n,l]) => (
                <div key={n} className="text-center px-3 sm:px-4 py-2.5 sm:py-3 rounded-xl flex-1 sm:flex-none min-w-[72px]"
                  style={{ background:"rgba(255,255,255,0.05)", border:"1px solid rgba(255,255,255,0.10)" }}>
                  <p className="font-black" style={{ fontSize:"16px", color:"var(--color-white)" }}>{n}</p>
                  <p style={{ fontSize:"10px", color:"var(--color-slate-400)", fontWeight:600 }}>{l}</p>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </div>

      {/* ── Body ── */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">

        {/* Step bar */}
        <div className="rounded-2xl px-4 sm:px-5 py-3.5 mb-6 flex items-center justify-between flex-wrap gap-3"
          style={{ background:"var(--color-background-card)", border:"1px solid var(--color-border-subtle)", boxShadow:"var(--shadow-sm)" }}>
          <StepIndicator current={step} />
          <div className="flex items-center gap-3">
            {/* Mobile preview button — only show on steps 1–3 */}
            {!submitted && step < 4 && (
              <button onClick={() => setSheetOpen(true)}
                className="lg:hidden flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-xl"
                style={{ background:"var(--color-primary-50)", color:"var(--color-accent-primary)", border:"1px solid var(--color-primary-100)" }}>
                <Eye className="w-3.5 h-3.5" /> Preview
              </button>
            )}
            <p style={{ fontSize:"11.5px", color:"var(--color-text-muted)", fontWeight:600 }}>
              Step {step} of {STEPS.length}
            </p>
          </div>
        </div>

        <div className="flex gap-6 lg:gap-7">

          {/* ── Form ── */}
          <div className="flex-1 min-w-0">
            <AnimatePresence mode="wait">
              {step===1 && <Step1 key="1" data={data} onChange={onChange} errors={errors} />}
              {step===2 && <Step2 key="2" data={data} onChange={onChange} errors={errors} />}
              {step===3 && <Step3 key="3" data={data} onChange={onChange} />}
              {step===4 && <Step4 key="4" data={data} onSubmit={() => setSubmitted(true)} submitted={submitted} />}
            </AnimatePresence>

            {/* Nav buttons */}
            {!submitted && (
              <div className="flex items-center justify-between mt-2 pb-10">
                <button onClick={prev} disabled={step===1}
                  className="btn btn-secondary flex items-center gap-2 px-5 py-2.5 text-sm font-bold rounded-xl"
                  style={{ opacity:step===1?0.35:1, cursor:step===1?"not-allowed":"pointer" }}>
                  <ChevronLeft className="w-4 h-4" /> Back
                </button>
                {step < 4 && (
                  <button onClick={next}
                    className="btn btn-primary flex items-center gap-2 px-6 sm:px-7 py-2.5 text-sm font-bold rounded-xl">
                    Continue <ChevronRight className="w-4 h-4" />
                  </button>
                )}
              </div>
            )}
          </div>

          {/* ── Sidebar (lg+) ── */}
          <aside className="hidden lg:block w-72 flex-shrink-0">
            <div className="sticky top-24 space-y-4">

              {/* Live preview */}
              <div className="rounded-2xl p-4"
                style={{ background:"var(--color-background-card)", border:"1px solid var(--color-border-subtle)", boxShadow:"var(--shadow-card)" }}>
                <div className="flex items-center gap-2 mb-4">
                  <Eye className="w-4 h-4" style={{ color:"var(--color-accent-primary)" }} />
                  <span className="font-black uppercase tracking-widest"
                    style={{ fontSize:"11px", color:"var(--color-text-secondary)" }}>Live Preview</span>
                </div>
                <PreviewCard data={data} />
              </div>

              {/* Tips */}
              <div className="rounded-xl p-4"
                style={{ backgroundImage:"linear-gradient(135deg, var(--color-primary-50) 0%, var(--color-sky-50) 100%)", border:"1px solid var(--color-primary-100)" }}>
                <Sparkles className="w-4 h-4 mb-2" style={{ color:"var(--color-accent-primary)" }} />
                <p className="font-bold mb-2" style={{ fontSize:"12.5px", color:"var(--color-text-primary)" }}>
                  Tips for a great listing
                </p>
                <ul className="space-y-1.5">
                  {[
                    "Write a clear, specific tagline",
                    "Pick perks candidates care about",
                    "Set accurate open job count",
                    "Choose a memorable cover gradient",
                  ].map(tip => (
                    <li key={tip} className="flex items-start gap-2"
                      style={{ fontSize:"11.5px", color:"var(--color-text-secondary)" }}>
                      <CheckCircle2 className="w-3 h-3 flex-shrink-0 mt-0.5" style={{ color:"var(--color-accent-primary)" }} />
                      {tip}
                    </li>
                  ))}
                </ul>
              </div>

              {/* Progress tracker */}
              <div className="rounded-xl p-4"
                style={{ background:"var(--color-background-card)", border:"1px solid var(--color-border-subtle)" }}>
                <p className="font-black uppercase tracking-widest mb-3"
                  style={{ fontSize:"10.5px", color:"var(--color-text-muted)" }}>Progress</p>
                <div className="space-y-2.5">
                  {STEPS.map(s => {
                    const done   = step > s.id;
                    const active = step === s.id;
                    const Icon   = s.icon;
                    return (
                      <div key={s.id} className="flex items-center gap-2.5">
                        <div className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0"
                          style={{ background: done?  "var(--color-emerald-100)"
                                            : active? "var(--color-primary-100)"
                                            : "var(--color-slate-100)" }}>
                          {done
                            ? <CheckCircle2 className="w-3.5 h-3.5" style={{ color:"var(--color-emerald-600)" }} />
                            : <Icon className="w-3 h-3" style={{ color: active?"var(--color-accent-primary)":"var(--color-text-muted)" }} />}
                        </div>
                        <span className="font-semibold" style={{
                          fontSize:"12.5px",
                          color: done?  "var(--color-emerald-700)"
                               : active?"var(--color-accent-primary)"
                               : "var(--color-text-muted)",
                        }}>{s.label}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

            </div>
          </aside>
        </div>
      </div>

      {/* ── Mobile preview bottom sheet ── */}
      <MobileSheet data={data} open={sheetOpen} onClose={() => setSheetOpen(false)} />
    </div>
  );
}